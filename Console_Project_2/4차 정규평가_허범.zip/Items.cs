﻿


public class Items()
{
    public void ItemPower()
    {
        // 아이템을 먹으면 AttackValue가 2배
    }

    public void ItemSpeed()
    {
        // 아이템을 먹으면 이동속도가 2배
    }

    public void ItemBullet()
    {
        // 아이템을 먹으면 BULLET을 두 개씩 발사 가능
    }
}
